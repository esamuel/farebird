var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/duffel-api.ts
var duffel_api_exports = {};
__export(duffel_api_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(duffel_api_exports);
var DUFFEL_API_URL = "https://api.duffel.com";
var DUFFEL_API_VERSION = "v1";
var handler = async (event) => {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Content-Type": "application/json"
  };
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers, body: "" };
  }
  const apiKey = process.env.DUFFEL_API_KEY;
  if (!apiKey) {
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: "DUFFEL_API_KEY not configured" })
    };
  }
  try {
    const body = JSON.parse(event.body || "{}");
    const { action, data } = body;
    let endpoint = "";
    let method = "POST";
    let requestBody;
    switch (action) {
      case "search":
        endpoint = "/offer_requests";
        requestBody = JSON.stringify({
          data: {
            slices: data.slices,
            passengers: data.passengers,
            cabin_class: data.cabin_class || "economy",
            return_offers: true
          }
        });
        break;
      case "get_offer":
        endpoint = `/offers/${data.offer_id}`;
        method = "GET";
        break;
      case "create_order":
        endpoint = "/orders";
        requestBody = JSON.stringify({
          data: {
            type: "instant",
            selected_offers: [data.offer_id],
            passengers: data.passengers,
            payments: [
              {
                type: "balance",
                amount: data.amount,
                currency: data.currency
              }
            ],
            metadata: data.metadata
          }
        });
        break;
      case "get_order":
        endpoint = `/orders/${data.order_id}`;
        method = "GET";
        break;
      case "list_airlines":
        endpoint = "/airlines";
        method = "GET";
        break;
      default:
        return {
          statusCode: 400,
          headers,
          body: JSON.stringify({ error: `Unknown action: ${action}` })
        };
    }
    const response = await fetch(`${DUFFEL_API_URL}/${DUFFEL_API_VERSION}${endpoint}`, {
      method,
      headers: {
        "Authorization": `Bearer ${apiKey}`,
        "Duffel-Version": "v1",
        "Content-Type": "application/json",
        "Accept": "application/json"
      },
      body: method !== "GET" ? requestBody : void 0
    });
    const responseData = await response.json();
    if (!response.ok) {
      console.error("Duffel API error:", responseData);
      return {
        statusCode: response.status,
        headers,
        body: JSON.stringify({
          error: responseData.errors?.[0]?.message || "Duffel API error",
          details: responseData
        })
      };
    }
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify(responseData)
    };
  } catch (error) {
    console.error("Duffel function error:", error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        error: error instanceof Error ? error.message : "Internal server error"
      })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
