var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/amadeus-search.ts
var amadeus_search_exports = {};
__export(amadeus_search_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(amadeus_search_exports);
var AMADEUS_CLIENT_ID = process.env.VITE_AMADEUS_CLIENT_ID || process.env.AMADEUS_CLIENT_ID || "";
var AMADEUS_CLIENT_SECRET = process.env.VITE_AMADEUS_CLIENT_SECRET || process.env.AMADEUS_CLIENT_SECRET || "";
var AMADEUS_BASE_URL = "https://test.api.amadeus.com";
var cachedToken = null;
var tokenExpiry = 0;
async function getAmadeusToken() {
  if (cachedToken && Date.now() < tokenExpiry) {
    return cachedToken;
  }
  const params = new URLSearchParams();
  params.append("grant_type", "client_credentials");
  params.append("client_id", AMADEUS_CLIENT_ID);
  params.append("client_secret", AMADEUS_CLIENT_SECRET);
  const response = await fetch(`${AMADEUS_BASE_URL}/v1/security/oauth2/token`, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: params
  });
  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`Amadeus auth failed: ${errorText}`);
  }
  const data = await response.json();
  cachedToken = data.access_token;
  tokenExpiry = Date.now() + data.expires_in * 1e3 - 6e4;
  return cachedToken;
}
var handler = async (event, context) => {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Content-Type": "application/json"
  };
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 204, headers, body: "" };
  }
  if (!AMADEUS_CLIENT_ID || !AMADEUS_CLIENT_SECRET) {
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        source: "AI",
        error: "Amadeus credentials not configured",
        data: []
      })
    };
  }
  try {
    const params = event.queryStringParameters || {};
    const { origin, destination, date, adults = "1", returnDate, cabinClass } = params;
    if (!origin || !destination || !date) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: "Missing required parameters: origin, destination, date" })
      };
    }
    const token = await getAmadeusToken();
    let url = `${AMADEUS_BASE_URL}/v2/shopping/flight-offers?originLocationCode=${origin}&destinationLocationCode=${destination}&departureDate=${date}&adults=${adults}&max=10`;
    if (returnDate) {
      url += `&returnDate=${returnDate}`;
    }
    if (cabinClass) {
      const cabinMap = {
        economy: "ECONOMY",
        premiumEconomy: "PREMIUM_ECONOMY",
        business: "BUSINESS",
        first: "FIRST"
      };
      url += `&travelClass=${cabinMap[cabinClass] || "ECONOMY"}`;
    }
    const response = await fetch(url, {
      headers: { Authorization: `Bearer ${token}` }
    });
    if (!response.ok) {
      const errorText = await response.text();
      console.error("Amadeus API Error:", response.status, errorText);
      console.error("Request URL:", url);
      throw new Error(`Amadeus API error: ${response.status} - ${errorText}`);
    }
    const data = await response.json();
    const flights = (data.data || []).map((offer) => {
      const itinerary = offer.itineraries[0];
      const firstSegment = itinerary.segments[0];
      const lastSegment = itinerary.segments[itinerary.segments.length - 1];
      const duration = itinerary.duration.replace("PT", "").replace("H", "h ").replace("M", "m").toLowerCase();
      const carrierCode = firstSegment.carrierCode;
      const airlineName = data.dictionaries?.carriers?.[carrierCode] || carrierCode;
      return {
        id: offer.id,
        airline: airlineName,
        flightNumber: `${carrierCode}${firstSegment.number}`,
        origin: firstSegment.departure.iataCode,
        destination: lastSegment.arrival.iataCode,
        departureTime: firstSegment.departure.at,
        arrivalTime: lastSegment.arrival.at,
        price: parseFloat(offer.price.total),
        currency: offer.price.currency,
        duration: duration.trim(),
        stops: itinerary.segments.length - 1,
        tags: ["Live Data"],
        baggageFees: {
          carryOn: 0,
          // Amadeus doesn't always provide this
          checkedBag: 35
          // Default estimate
        }
      };
    });
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        source: "API",
        data: flights
      })
    };
  } catch (error) {
    console.error("Amadeus function error:", error);
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        source: "AI",
        error: error instanceof Error ? error.message : "Unknown error",
        data: []
      })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
